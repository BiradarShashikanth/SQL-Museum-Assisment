create database Museum_1;
use museum_1;
create table met(
ID INT PRIMARY KEY,
Department varchar(100),
Category varchar(100),
Title varchar(100),
Artist varchar(100),
Date varchar(100),
Medium varchar(100),
Country varchar(100));

select * from met;

-- Select the top 10 rows in the met table.

select * from met
order by ID
limit 10;

-- How many pieces are in the American Metropolitan Art collection? [count(*)]
select * from met;

select count(*) 
from met
WHERE department = 'American Metropolitan Art';

-- Count the number of pieces where the category includes ‘celery’.

select count(*) 
from met
where category like('%celery%');

select count(*) as cat_cnt
from met
where category like('%celery%');

-- Find the title and medium of the oldest piece(s) in the collection.

select * from met;

select title, medium
from met
order by date asc
limit 1;


-- Find the top 10 countries with the most pieces in the collection.

select country, count(*) as pie_cnt 
from met
group by country
order by pie_cnt desc
limit 10;

-- Find the categories which have more than 100 pieces.

select * from met;

select category, count(*) as cat_cnt 
from met
group by category
having count(*) >100;

-- Count the number of pieces where the medium contains ‘gold’ or ‘silver’ and sort in descending order.

select * from met;

select medium, count(*) as med_cnt
from met
where medium like ('%gold%') or medium like ('%silver%')
group by medium
order by med_cnt desc;
